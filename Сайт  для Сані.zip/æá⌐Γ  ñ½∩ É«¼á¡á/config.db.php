<?php
/**
 * <en> Type of database server </en>
 * <ru> Тип сервера баз данних </ru>
 */
$config['db_config']['db_server'] = 'mysql';

/**
 * <en> Address of the host </en>
 * <ru> Адрес хосту </ru>
 */
$config['db_config']['db_hostname']='localhost';

/**
 * <en> Port for connection </en>
 * <ru> Порт для підключення </ru>
 */
$config['db_config']['db_port'] = '3306';

/**
 * <en> User name </en>
 * <ru> Ім'я юзера </ru>
 */
$config['db_config']['db_username']='lookin7777';

/**
 * <en> Password </en>
 * <ru> Пароль </ru>
 */
$config['db_config']['db_password']='dyndyn777';

/**
 * <en> Name of your database </en>
 * <ru> Ім'я бази данних </ru>
 */
$config['db_config']['db_databasename']='lookin7777';

/**
 * <en> Encoding control </en>
 * <ru> Управління кодом </ru>
 */
$config['setNames'] = "SET NAMES utf8";

/**
 * <en> Table prefix </en>
 * <ru> Префікс таблиць </ru>
 */
$config['db_delimiters']['RAD'] = 'rad_';