RADPAGINATOR = {
    'init': function(id)
    {
        //
    }
}