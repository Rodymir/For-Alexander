<h3><?php echo app::lang('step6_title') ?></h3>

<p style="text-align:center">
    <?php echo app::lang('step6_txt1') ?><br><br>
    <a href="/index.php"><?php echo app::lang('step6_txt2') ?></a>
</p>