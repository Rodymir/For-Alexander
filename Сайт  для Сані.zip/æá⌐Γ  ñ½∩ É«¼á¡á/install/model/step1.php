<?php
return array(
        'license'=>array(
            'required'=>true,
            'error'=>false,
            'value'=>'',
        ),
);